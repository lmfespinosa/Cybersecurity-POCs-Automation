self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7af2aa7b96cce261fa87b312ad9f670b",
    "url": "/index.html"
  },
  {
    "revision": "23eeac928954729240be",
    "url": "/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "260d135e8d8b717bf145",
    "url": "/static/js/2.9598ca2c.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.9598ca2c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "23eeac928954729240be",
    "url": "/static/js/main.e2a031f2.chunk.js"
  },
  {
    "revision": "3f809adccd7b5eb81ce7",
    "url": "/static/js/runtime-main.6d8ceafa.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);